<?php
$config = [
"imei" => "868473037901071",
"sign" => "6eb55e8eba64bc71250d75a1f17141045a65d2f3",
"token" => "5b4fbefeced1c58e3e608490ac4d4380",
"uuid" => "cba9b745-0ad2-44fd-929b-cf8e5422c4ba"
];